<html lang="es">
    <head>
        <meta charset=utf-8/>
        <style>
            #main{background-color: #000;}
        </style>
    </head>
    <body id="main">
        <div id='player'>
            <video id="vidarea" class="video-js vjs-default-skin" width="100%" height="100%" controls autoplay ></video>
            
            <script>
            var link = "https://dai.google.com/linear/hls/event/7-91LhuBQNONHzAbrFQr-Q/master.m3u8";    
            var vid = document.getElementById("vidarea");
            vid.src = link;
            </script> 
       
        </div>
    </body>
</html>