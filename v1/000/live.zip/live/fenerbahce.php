<html lang="es">
    <head>
        <meta charset=utf-8/>
        <style>
            #main{background-color: #000;}
        </style>
    </head>
    <body id="main">
        <div id='player'>
            <video id="vidarea" class="video-js vjs-default-skin" width="100%" height="100%" controls autoplay ></video>
            
            <script>
            var link = "https://stream-02.nyc.dailymotion.com/sec(1zZZZ1Jh3MWAQUOGa2TxYmJJGX42_tVXfAIJr7ETHck)/dm/3/x21oo10/s/live-3.m3u8";    
            var vid = document.getElementById("vidarea");
            vid.src = link;
            </script> 
       
        </div>
    </body>
</html>