<html lang="es">
    <head>
        <meta charset=utf-8/>
        <style>
            #main{background-color: #000;}
        </style>
    </head>
    <body id="main">
        <div id='player'>
            <video id="vidarea" class="video-js vjs-default-skin" width="100%" height="100%" controls autoplay ></video>
            
            <script>
            var link = "https://www.streamaway.net/fra/frpx/frprx.php/Z2x5cGV8fGh0dHBzOi8vb25saW5lcHJveHkuZXUvYnJvd3NlLnBocD91PQ==/catchup.iptv.iinet.rs/chunklist.m3u8?id=172&profile=3&token=dG9rZW49LVkzblctbGw0RUdzSWhVWWdDUlNiUjZMbGpBbkVUNzgmaWQ9NzImc2VjcmV0PW90dA";    
            var vid = document.getElementById("vidarea");
            vid.src = link;
            </script> 
       
        </div>
    </body>
</html>