<html lang="es">
    <head>
        <meta charset=utf-8/>
        <style>
            #main{background-color: #000;}
        </style>
    </head>
    <body id="main">
        <div id='player'>
            <video id="vidarea" class="video-js vjs-default-skin" width="100%" height="100%" controls autoplay ></video>
            
            <script>
            var link = "https://bcovlive-a.akamaihd.net/54ce1b91702c4d62930fa4a71eabf8af/us-west-2/6141518204001/playlist.m3u8";    
            var vid = document.getElementById("vidarea");
            vid.src = link;
            </script> 
       
        </div>
    </body>
</html>